#!/bin/bash

redis-server --save 20 1 --loglevel warning --requirepass blablablablablablablablablablabla --daemonize yes

flask run 
