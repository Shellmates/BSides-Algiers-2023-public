
```bash
adb shell getevent | grep "touchscreen" -A 1  
adb shell cat /dev/input/event2 > evtx  
md5sum event2
#f241a508d5fccea7eb0f33a839a9633f
```

Retrieve the lock pattern, and wrap it with the flag format.
Flag format: shellmates{[1-9]+} 
